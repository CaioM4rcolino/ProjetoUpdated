function relatorioMensal($idRegistro, $tipoRelatorio){

//Import do arquivo de Variaveis e Constantes
require_once('../modulo/config.php');

//Import do arquivo de função para conectar no BD  
require_once('conexaoMysql.php');

if(!$conex = conexaoMysql())
{
echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
//die; //Finaliza a interpretação da página
}

$informacao = contagemEValor($tipoRelatorio);

$sqlSelect = "select * from rendimento";
$select = mysqli_query($conex, $sqlSelect);
$rsRelatoriomensal = mysqli_fetch_assoc($select);

if($rsRelatoriomensal['qtde_de_clientes'] == null && $rsRelatoriomensal['valorTotal'] == null){

  $sqlInsert = "insert into rendimentomensal(mes, qtde_de_clientes, valorTotal, idRegistro)
  values(

  month(curdate()), 
  ".$informacao[0]['qtde_de_clientes'].", 
  ".$informacao[0]['valorTotal'].", 
  ".$idRegistro."

      )";

  mysqli_query($conex, $sqlInsert);

  $sqlSelect = "select * from rendimentomensal";
  $select = mysqli_query($conex, $sqlSelect);

  while($rsRelatoriomensal = mysqli_fetch_assoc($select)){

      $dados[] = array(

          "data"                  => $rsRelatoriomensal['mes'],
          "quantidadeDeClientes"  => $rsRelatoriomensal['qtde_de_clientes'],
          "valorTotal"            => "R$".$rsRelatoriomensal['valorTotal']

      );

    
      
      if(isset($dados))
          return $dados;
      else
          return false;
  }


}
elseif($rsRelatoriomensal['qtde_de_clientes'] != $informacao[0]['qtde_de_clientes'] || $rsRelatoriomensal['valorTotal'] != $informacao[0]['valorTotal'])
{
  $sqlUpdate = "update rendimentomensal set

  mes = month(current_date()),
  qtde_de_clientes = ".$informacao[0]['qtde_de_clientes'].",
  valorTotal = ".$informacao[0]['valorTotal']."

  where rendimentoMensal.idRegistro = ".$idRegistro;

  mysqli_query($conex, $sqlUpdate);

  $sqlSelect = "select * from rendimentoMensal";
  $select = mysqli_query($conex, $sqlSelect);

  while($rsRelatorioMensal = mysqli_fetch_assoc($select)){

      $dados[] = array(

          "data"                  => $rsRelatorioMensal['mes'],
          "quantidadeDeClientes"  => $rsRelatorioMensal['qtde_de_clientes'],
          "valorTotal"            => "R$".$rsRelatorioMensal['valorTotal']

      );


      if(isset($dados))
          return $dados;
      else
          return false;

  }
}
else{

  $sqlSelect = "select * from rendimentoMensal";
  $select = mysqli_query($conex, $sqlSelect);

  while($rsRelatorioMensal = mysqli_fetch_assoc($select)){

      $dados[] = array(

          "data"                  => $rsRelatorioMensal['mes'],
          "quantidadeDeClientes"  => $rsRelatorioMensal['qtde_de_clientes'],
          "valorTotal"            => "R$".$rsRelatorioMensal['valorTotal']

      );

  if(isset($dados))
      return $dados;
  else
      return false;


  }

}

}