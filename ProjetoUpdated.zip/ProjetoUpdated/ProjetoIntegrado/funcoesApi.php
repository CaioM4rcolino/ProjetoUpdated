<?php

function listarClientes($id){

 //Import do arquivo de Variaveis e Constantes
 require_once('modulo/config.php');

 //Import do arquivo de função para conectar no BD  
 require_once('conexaoMysql.php');

 if(!$conex = conexaoMysql())
 {
     echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
     //die; //Finaliza a interpretação da página
 }

 $sql = "select tblCliente.*, tblVeiculo.placa, tblVeiculo.cor
        from tblCliente, tblVeiculo
        where tblCliente.idVeiculo = tblVeiculo.idVeiculo";

        if ($id > 0) {
            $sql = $sql . " and tblCliente.idCliente = " . $id;
        }
    
        $select = mysqli_query($conex, $sql);
        
        while($rsClientes = mysqli_fetch_assoc($select)) {
            //varios itens para o json
            $dados[] = array (
                //          => - o que alimenta o dado de um array
                'idCliente'         => $rsClientes['idCliente'],
                'nomeCliente'       => $rsClientes['nomeCliente'],
                'placa'             => $rsClientes['placa'],
                'cor'               => $rsClientes['cor'],
                'horarioEntrada'    => $rsClientes['horarioEntrada'],
                'horarioSaida'      => $rsClientes['horarioSaida'],
                'valorAPagar'       => "R$".$rsClientes['valorAPagar']
             
            );            
        }
    
    if(isset($dados))
        return $dados;
    else 
        return false;

}


function inserirCliente($dadosCliente){
  
    //Import do arquivo de Variaveis e Constantes
    require_once('modulo/config.php');

    //Import do arquivo de função para conectar no BD  
    require_once('conexaoMysql.php');

    if(!$conex = conexaoMysql())
    {
        echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
        //die; //Finaliza a interpretação da página
    }

    $nomeCliente = $dadosCliente['nomeCliente'];
    $placa = $dadosCliente['placa'];
    $cor = $dadosCliente['cor'];
    

    $sql1 = "insert into tblVeiculo(placa, cor)
             values('".$placa."', '".$cor."')
            ";

    if(mysqli_query($conex, $sql1)){

            $sqlIdVeiculo = "select * from tblVeiculo order by idVeiculo desc limit 1";

            $selectIdVeiculo = mysqli_query($conex, $sqlIdVeiculo);
            
            $rsVeiculo = mysqli_fetch_assoc($selectIdVeiculo);

            
            $sql2 = "insert into tblCliente(nomeCliente, horarioEntrada, idVeiculo, horarioSaida, valorAPagar)
                    values('".$nomeCliente."', curtime(), '".$rsVeiculo['idVeiculo']."', null, 'null')
                    ";

        if(mysqli_query($conex, $sql2))
            return $dadosCliente;
        else
            return false;

    }         
    
    

}

function excluirCliente($id){

        //Import do arquivo de Variaveis e Constantes
        require_once('modulo/config.php');

        //Import do arquivo de função para conectar no BD  
        require_once('conexaoMysql.php');
    
        if(!$conex = conexaoMysql())
        {
            echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
            //die; //Finaliza a interpretação da página
        }

    $sqlIdVeiculo = "select * from tblVeiculo order by idVeiculo desc limit 1";

    $selectIdVeiculo = mysqli_query($conex, $sqlIdVeiculo);
        
    $rsVeiculo = mysqli_fetch_assoc($selectIdVeiculo);

        if($id > 0){
        
            $sql = "delete from tblCliente where idCliente = ".$id;

            $sql2 = "delete from tblVeiculo where idVeiculo = ".$rsVeiculo['idVeiculo'];
            
           if (mysqli_query($conex, $sql))
            if(mysqli_query($conex, $sql2))
               return true;
           else 
               return false;
           
        }
    
}

function atualizarCliente($id){
    
    //Import do arquivo de Variaveis e Constantes
  require_once('../modulo/config.php');

  //Import do arquivo de função para conectar no BD  
  require_once('conexaoMysql.php');

  if(!$conex = conexaoMysql())
  {
      echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
      //die; //Finaliza a interpretação da página
  }


    $atualizarHorarioSaida = "update tblCliente set

                          horarioSaida = curtime()

                          where idCliente = " . $id;

    mysqli_query($conex, $atualizarHorarioSaida);

    $valorAPagar = calcularValorFinal($id);


    $atualizarValorFinal = "update tblCliente set
                    
                        valorAPagar = ".$valorAPagar."

                        where idCliente = " . $id;

                   
    mysqli_query($conex, $atualizarValorFinal);


    $sql = "select tblCliente.*, tblVeiculo.placa, tblVeiculo.cor  
         from tblCliente, tblVeiculo
         where tblCliente.idCliente = ".$id."
         and tblCliente.idVeiculo = tblVeiculo.idVeiculo";


    $select = mysqli_query($conex, $sql);

        while($rsClientes = mysqli_fetch_assoc($select))
        {
             //varios itens para o json
             $dados[] = array (
                 //          => - o que alimenta o dado de um array
                 'idCliente'         => $rsClientes['idCliente'],
                 'nomeCliente'       => $rsClientes['nomeCliente'],
                 'placa'             => $rsClientes['placa'],
                 'cor'               => $rsClientes['cor'],
                 'horarioEntrada'    => $rsClientes['horarioEntrada'],
                 'horarioSaida'      => $rsClientes['horarioSaida'],
                 'valorAPagar'       => "R$".$rsClientes['valorAPagar']
              
             ); 

        }
    

    if(isset($dados))
         return $dados;
    else 
         return false;
  
}

function convertJson($data) {
    header("Content-Type:application/json"); // forçando o cabeçalho do arquivo a ser aplicação do tipo json
    $listJson = json_encode($data); // codificando em json   
    return $listJson;
}

function calcularValorFinal($id){

    //Import do arquivo de Variaveis e Constantes
    require_once('modulo/config.php');

    //Import do arquivo de função para conectar no BD  
    require_once('conexaoMysql.php');

    if(!$conex = conexaoMysql())
    {
        echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
        //die; //Finaliza a interpretação da página
    }

    $diferencaHorarios = "select timediff(tblCliente.horarioSaida, tblCliente.horarioEntrada) as diferencaHorarios from tblCliente
    where tblCliente.idCliente = ".$id;
    
    //mysqli_query para validar o script
    $queryDiferencaHorarios = mysqli_query($conex, $diferencaHorarios);
    
    //transforma o script em um array associativo
    $rsDiferencaHorarios = mysqli_fetch_assoc($queryDiferencaHorarios);
    
    $timeDiffHour = explode(":", $rsDiferencaHorarios['diferencaHorarios']);

    //uso da função subtrairTempo para subtrair dois valores que correspondem a horas, retorna um int
    $demaisHoras = subtrairHora($rsDiferencaHorarios['diferencaHorarios'], "1:00:00");
    $primeiraHora = subtrairHora($rsDiferencaHorarios['diferencaHorarios'], $demaisHoras);

    $sqlRegistro = "select * from tblRegistro";
    
    $queryRegistro = mysqli_query($conex, $sqlRegistro);

    $rsRegistro = mysqli_fetch_assoc($queryRegistro);
    
            //operação para calcular o valor final pago, considerando o valor da primeira hora e o valor para cada hora restante
            $valorPrimeiraHora = (int)$rsRegistro['valorPrimeiraHora'];
            $valorDemaisHoras  = (int)$rsRegistro['valorDemaisHoras'];
            $desconto = (int)$rsRegistro['desconto'];
    
            $valorFinal = ($primeiraHora*$valorPrimeiraHora) + $demaisHoras * $valorDemaisHoras;

            if($timeDiffHour[0] == "00"){

                $valorFinal = 0;
                return $valorFinal;

            }
            else if($desconto > 0){

                $desconto = $desconto/100;
                $valorComDesconto = $valorFinal * $desconto;

                $valorFinal = $valorFinal - $valorComDesconto;

                return $valorFinal;
                

            }
            else{
                      
                return $valorFinal;

            }  

  

}

function subtrairHora($tempoA, $tempoB){

    $arrayTempoA = explode(":", $tempoA);
    $arrayTempoB = explode(":", $tempoB);

    /*com o explode eu divido o formato de horário "00:00:00" em um array desta forma
    Ex: 17:30:15
    
    array(

        [0]-> 17,
        [1]-> 30,
        [2]-> 15

    );

    */

    $tempoAInt = (int)$arrayTempoA[0];
    $tempoBInt = (int)$arrayTempoB[0];

    $subtracaoHoras = $tempoAInt - $tempoBInt;



    return $subtracaoHoras;

}

function inserirRegistro($dadosJson){

    //Import do arquivo de Variaveis e Constantes
  require_once('../modulo/config.php');

  //Import do arquivo de função para conectar no BD  
  require_once('conexaoMysql.php');

  if(!$conex = conexaoMysql())
  {
      echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
      //die; //Finaliza a interpretação da página
  }

  $valorPrimeiraHora = $dadosJson['valorPrimeiraHora'];
  $valorDemaisHoras = $dadosJson['valorDemaisHoras'];
  $quantidadeDeVagas = $dadosJson['quantidadeDeVagas'];
  $desconto = $dadosJson['desconto'];


  $sql = "insert into tblregistro(valorPrimeiraHora, valorDemaisHoras, qtde_de_vagas, desconto)
          values('".$valorPrimeiraHora."', '".$valorDemaisHoras."', '".$quantidadeDeVagas."', '".$desconto."')";

    if(mysqli_query($conex, $sql))
        return $dadosJson;
    else
        return false;

    
}

function listarRegistro(){


    //Import do arquivo de Variaveis e Constantes
    require_once('modulo/config.php');

    //Import do arquivo de função para conectar no BD  
    require_once('conexaoMysql.php');

    if(!$conex = conexaoMysql())
    {
        echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
        //die; //Finaliza a interpretação da página
    }

     $sql = "select * from tblRegistro";

        $select = mysqli_query($conex, $sql);
        
        while($rsRegistro = mysqli_fetch_assoc($select)) {
            //varios itens para o json
            $dados[] = array (
                //          => - o que alimenta o dado de um array
                'idRegistro'              => $rsRegistro['idRegistro'],
                'valorPrimeiraHora'       => $rsRegistro['valorPrimeiraHora'],
                'valorDemaisHoras'        => $rsRegistro['valorDemaisHoras'],
                'quantidadeDeVagas'       => $rsRegistro['qtde_de_vagas'],
                'desconto'                => $rsRegistro['desconto']
             
            );            
        }

    
    if(isset($dados))
        return $dados;
    else 
        return false;

}

function atualizarRegistro($dadosRegistro){

  //Import do arquivo de Variaveis e Constantes
  require_once('../modulo/config.php');

  //Import do arquivo de função para conectar no BD  
  require_once('conexaoMysql.php');

  if(!$conex = conexaoMysql())
  {
      echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
      //die; //Finaliza a interpretação da página
  }

  $getRegistro = listarRegistro();

  $valorPrimeiraHora = $dadosRegistro['valorPrimeiraHora'];
  $valorDemaisHoras = $dadosRegistro['valorDemaisHoras'];
  $quantidadeDeVagas = $dadosRegistro['quantidadeDeVagas'];
  $desconto = $dadosRegistro['desconto'];

  $update = "update tblRegistro set

          valorPrimeiraHora = ".$valorPrimeiraHora.",
          valorDemaisHoras = ".$valorDemaisHoras.",
          qtde_de_vagas = ".$quantidadeDeVagas.",
          desconto = ".$desconto."
          where idRegistro = ".$getRegistro[0]['idRegistro'];

    mysqli_query($conex, $update);

    $sql = "select * from tblRegistro";

    $select= mysqli_query($conex, $sql);

        while($rsRegistroAtualizado = mysqli_fetch_assoc($select)) {
            //varios itens para o json
            $dadosAtualizados[] = array (
                //          => - o que alimenta o dado de um array
                'idRegistro'              => $rsRegistroAtualizado['idRegistro'],
                'valorPrimeiraHora'       => $rsRegistroAtualizado['valorPrimeiraHora'],
                'valorDemaisHoras'        => $rsRegistroAtualizado['valorDemaisHoras'],
                'quantidadeDeVagas'       => $rsRegistroAtualizado['qtde_de_vagas'],
                'desconto'                => $rsRegistroAtualizado['desconto']."%"
            
            );            
        }

    if(isset($dadosAtualizados)){

        return $dadosAtualizados;

    }
    else{
        return false;
    }

}

function excluirRegistro($id){
 
  //Import do arquivo de Variaveis e Constantes
  require_once('../modulo/config.php');

  //Import do arquivo de função para conectar no BD  
  require_once('conexaoMysql.php');

  if(!$conex = conexaoMysql())
  {
      echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
      //die; //Finaliza a interpretação da página
  }

  $sql = "delete from tblRegistro where tblRegistro.idRegistro = ".$id;

  if(mysqli_query($conex, $sql))
    return true;
  else
    return false;

  

}

function listarClientesPagantes($args){

 //Import do arquivo de Variaveis e Constantes
 require_once('modulo/config.php');

 //Import do arquivo de função para conectar no BD  
 require_once('conexaoMysql.php');

 if(!$conex = conexaoMysql())
 {
     echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
     //die; //Finaliza a interpretação da página
 }

 $sql = "select tblCliente.*, tblVeiculo.placa, tblVeiculo.cor
        from tblCliente, tblVeiculo
        where tblCliente.idVeiculo = tblVeiculo.idVeiculo
        and tblCliente.valorAPagar <> 'null'";

        if($args == 'diario'){

            $sql = $sql . "and day(tblCliente.horarioSaida) = day(current_date())";
        }

        if($args == 'mensal'){

            $sql = $sql . "and month(tblCliente.horarioSaida) = month(current_date())";
        }

        if($args == 'anual'){

            $sql = $sql . "and year(tblCliente.horarioSaida) = year(current_date())";
        }
       

        $select = mysqli_query($conex, $sql);
        
        while($rsClientes = mysqli_fetch_assoc($select)) {
            //varios itens para o json
            $dados[] = array (
                //          => - o que alimenta o dado de um array
                'idCliente'         => $rsClientes['idCliente'],
                'nomeCliente'       => $rsClientes['nomeCliente'],
                'placa'             => $rsClientes['placa'],
                'cor'               => $rsClientes['cor'],
                'horarioEntrada'    => $rsClientes['horarioEntrada'],
                'horarioSaida'      => $rsClientes['horarioSaida'],
                'valorAPagar'       => "R$".$rsClientes['valorAPagar']
             
            );            
        }

    
    if(isset($dados))
        return $dados;
    else 
        return false;

}

function relatorio($idRegistro, $args){

  //Import do arquivo de Variaveis e Constantes
  require_once('../modulo/config.php');

  //Import do arquivo de função para conectar no BD  
  require_once('conexaoMysql.php');

  if(!$conex = conexaoMysql())
  {
      echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
      //die; //Finaliza a interpretação da página
  }

  $sqlQtdeClientes = "select count(*) as qtdeClientes from tblCliente
                      where tblCliente.valorAPagar <> 'null'";
                      
  $selectQtdeClientes = mysqli_query($conex, $sqlQtdeClientes);
  $qtde_de_clientes = mysqli_fetch_assoc($selectQtdeClientes);

  $sqlValorTotal = "select sum(valorAPagar) as valorTotal from tblCliente
                    where tblCliente.valorAPagar <> 'null'";
                    
  $selectValorTotal = mysqli_query($conex, $sqlValorTotal);
  $valorTotal = mysqli_fetch_assoc($selectValorTotal);

  $sqlSelect = "select * from rendimentoDiario";
  $select = mysqli_query($conex, $sqlSelect);
  $rsRelatorioDiario = mysqli_fetch_assoc($select);

switch($args){

    case 'diario':
        $sqlQtdeClientes = $sqlQtdeClientes . "and day(tblCliente.horarioSaida) = day(current_date())";
        $sqlValorTotal = $sqlValorTotal . "and day(tblCliente.horarioSaida) = day(current_date())";
        break;
    
    case 'mensal':
        $sqlQtdeClientes = $sqlQtdeClientes . "and month(tblCliente.horarioSaida) = month(current_date())";
        $sqlValorTotal = $sqlValorTotal . "and month(tblCliente.horarioSaida) = month(current_date())";
        break;
    
    case 'anual':
        $sqlQtdeClientes = $sqlQtdeClientes . "and year(tblCliente.horarioSaida) = year(current_date())";
        $sqlValorTotal = $sqlValorTotal . "and year(tblCliente.horarioSaida) = year(current_date())";
        break;

}
    if($rsRelatorioDiario['qtde_de_clientes'] == null && $rsRelatorioDiario['valorTotal'] == null){

        $sqlInsert = "insert into rendimentoDiario(data, qtde_de_clientes, valorTotal, idRegistro)
        values(

        curdate(), 
        ".$qtde_de_clientes['qtdeClientes'].", 
        ".$valorTotal['valorTotal'].", 
        ".$idRegistro."

            )";

        mysqli_query($conex, $sqlInsert);

        $sqlSelect = "select * from rendimentoDiario";
        $select = mysqli_query($conex, $sqlSelect);

        while($rsRelatorioDiario = mysqli_fetch_assoc($select)){

            $dados[] = array(
    
                "data"                  => $rsRelatorioDiario['data'],
                "quantidadeDeClientes"  => $rsRelatorioDiario['qtde_de_clientes'],
                "valorTotal"            => "R$".$rsRelatorioDiario['valorTotal']
    
            );

          
            
            if(isset($dados))
                return $dados;
            else
                return false;
        }


    }
    elseif($rsRelatorioDiario['qtde_de_clientes'] != $qtde_de_clientes['qtdeClientes'] || $rsRelatorioDiario['valorTotal'] != $valorTotal['valorTotal'])
    {
        $sqlUpdate = "update rendimentoDiario set

        data = current_date(),
        qtde_de_clientes = ".$qtde_de_clientes['qtdeClientes'].",
        valorTotal = ".$valorTotal['valorTotal']."

        where rendimentoDiario.idRegistro = ".$idRegistro;

        mysqli_query($conex, $sqlUpdate);

        $sqlSelect = "select * from rendimentoDiario";
        $select = mysqli_query($conex, $sqlSelect);

        while($rsRelatorioDiario = mysqli_fetch_assoc($select)){

            $dados[] = array(
    
                "data"                  => $rsRelatorioDiario['data'],
                "quantidadeDeClientes"  => $rsRelatorioDiario['qtde_de_clientes'],
                "valorTotal"            => "R$".$rsRelatorioDiario['valorTotal']
    
            );


            if(isset($dados))
                return $dados;
            else
                return false;

        }
    }
    else{

        $sqlSelect = "select * from rendimentoDiario";
        $select = mysqli_query($conex, $sqlSelect);

        while($rsRelatorioDiario = mysqli_fetch_assoc($select)){

            $dados[] = array(
    
                "data"                  => $rsRelatorioDiario['data'],
                "quantidadeDeClientes"  => $rsRelatorioDiario['qtde_de_clientes'],
                "valorTotal"            => "R$".$rsRelatorioDiario['valorTotal']
    
            );

        if(isset($dados))
            return $dados;
        else
            return false;


        }
     
    }


}