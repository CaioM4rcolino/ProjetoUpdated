'use strict'

const containerConteudo = document.getElementById('clientes');

const consultaCliente = document.getElementById('consultarCliente');

const chamaCliente = document.getElementById('index-cliente');

const relatorios = document.getElementById('relatorios');

const chamaRelatorio = document.getElementById('index-relatorio');

/*SEÇÃO DE ATUALIZAR O RELATÓRIO*/

const chamaDiaria = document.getElementById('chamaDiaria');

function consulta() {
    
    chamaRelatorio.style.display = 'none';
    
    chamaCliente.style.display = 'block';
    
}


function relatorio() {
    
   chamaCliente.style.display = 'none';
    
   chamaRelatorio.style.display = 'block';
} 

function diaria() {
   
    let containerRelatorio = document.getElementById('segura-tblRelatorio');
    
    containerRelatorio.innerHTML = `
        <table id="tblRelatorio" class="centerObject">
                        <tr class="tr-relatorio">
                            <td class="td-titulo">ID</td>
                            <td class="td-titulo">Nome</td>
                            <td class="td-titulo">Placa</td>
                            <td class="td-titulo">Cor</td>
                            <td class="td-titulo">Dia</td>
                            <td class="td-titulo">Hora Total</td>
                            <td class="td-titulo">Valor Pago</td>
                            <td class="td-titulo">Ticket</td>
                        </tr>
                        <tr class="tr-relatorio">
                            <td class="td-relatorio">1</td>
                            <td class="td-relatorio">Alencar Teixeira Rodrigues Fagundes</td>
                            <td class="td-relatorio">CUA-1278</td>
                            <td class="td-relatorio">Amarelo</td>
                            <td class="td-relatorio">17/12/2020</td>
                            <td class="td-relatorio">1:50:57</td>
                            <td class="td-relatorio">R$20</td>
                            <td class="td-relatorio">
                                <div id="button-comprovante">
                                    <input type="button" name="btnCadastrar" value="Gerar Ticket" class="gerar-ticket">
                                </div>
                            </td>
                        </tr>
                        <tr class="tr-relatorio">
                            <td class="td-relatorio">2</td>
                            <td class="td-relatorio"></td>
                            <td class="td-relatorio"></td>
                            <td class="td-relatorio"></td>
                            <td class="td-relatorio"></td>
                            <td class="td-relatorio"></td>
                            <td class="td-relatorio"></td>
                            <td class="td-relatorio"></td>
                        </tr>                        
                    </table>
                    <div id="caixa-informacoes-importantes">
                        <table id="tblInformacoes-importantes">
                            <tr class="tr-relacao">
                                <td class="td-relacao">Valor Total Do Dia :</td>
                                <td class="td-relacao">R$2500.50</td>
                            </tr>
                            <tr class="tr-relacao">
                                <td class="td-relacao">Qtdes de Carros Dia :</td>
                                <td class="td-relacao">50 Carros</td>
                            </tr>
                        </table>
                    </div>
    `;
}


consultarCliente.addEventListener('click', consulta);
relatorios.addEventListener('click', relatorio);
chamaDiaria.addEventListener('change', diaria);


